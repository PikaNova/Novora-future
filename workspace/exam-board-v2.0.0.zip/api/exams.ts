import type { VercelRequest, VercelResponse } from '@vercel/node';
import { neon } from '@neondatabase/serverless';
import { canAccessClass, canAccessGrade, hasPermission, isPasswordRequired, requireActor, writeAudit, type AdminActor, type Permission } from './_auth.js';

// 性能：缓存 neon 客户端（同一 warm 实例复用）。
let _sql: ReturnType<typeof neon> | null = null;
function database() {
  if (_sql) return _sql;
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error('DATABASE_URL is not set');
  _sql = neon(connectionString);
  return _sql;
}

// 建表/迁移只需执行一次：用模块级 Promise 缓存，避免每个请求都跑 6 条 DDL。
// （数据库在新加坡、Vercel 在美国，每条 SQL 都是一次跨洲 HTTP 往返，
// 以前每次 GET/POST 都做 6 次 DDL 往返→累计 2-3 秒。现改为按需且仅一次。)
let migratePromise: Promise<void> | null = null;
let updatedAtMigrationPromise: Promise<void> | null = null;
type CachedGet = { body: string; etag: string; expiresAt: number };
let getCache: CachedGet | null = null;
const GET_CACHE_MS = 10_000;

// 早期版本曾将 updated_at 建为 INTEGER；毫秒时间戳超过其上限时，将旧列无损扩展为 BIGINT。
// 仅在旧表首次写入溢出、或按需建表迁移时执行，避免每次请求增加 DDL 往返。
function ensureUpdatedAtBigIntOnce(): Promise<void> {
  if (!updatedAtMigrationPromise) {
    updatedAtMigrationPromise = (async () => {
      const sql = database();
      await sql`ALTER TABLE exam_data ALTER COLUMN updated_at TYPE BIGINT USING updated_at::BIGINT`;
    })().catch(err => { updatedAtMigrationPromise = null; throw err; });
  }
  return updatedAtMigrationPromise;
}

function ensureTableOnce(): Promise<void> {
  if (!migratePromise) {
    migratePromise = (async () => {
      const sql = database();
      await sql`
        CREATE TABLE IF NOT EXISTS exam_data (
          id INTEGER PRIMARY KEY DEFAULT 1,
          items JSONB NOT NULL DEFAULT '[]',
          title TEXT NOT NULL DEFAULT '',
          majors JSONB NOT NULL DEFAULT '[]',
          active_major_id TEXT NOT NULL DEFAULT '',
          alerts JSONB,
          weekly_plans JSONB NOT NULL DEFAULT '[]',
          schedule_mode TEXT NOT NULL DEFAULT 'major-only',
          active_weekly_plan_id TEXT NOT NULL DEFAULT '',
          active_weekly_plan_by_class JSONB NOT NULL DEFAULT '{}',
          weekly_conflict_policy JSONB,
          grades JSONB NOT NULL DEFAULT '[]',
          classes JSONB NOT NULL DEFAULT '[]',
          initialization JSONB NOT NULL DEFAULT '{}',
          updated_at BIGINT NOT NULL DEFAULT 0,
          CHECK (id = 1)
        )
      `;
      // 兼容未重置的旧库；并行执行可避免免费函数冷启动串行累加跨洲数据库延迟。
      await Promise.all([
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS majors JSONB NOT NULL DEFAULT '[]'`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS active_major_id TEXT NOT NULL DEFAULT ''`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS alerts JSONB`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS weekly_plans JSONB NOT NULL DEFAULT '[]'`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS schedule_mode TEXT NOT NULL DEFAULT 'major-only'`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS active_weekly_plan_id TEXT NOT NULL DEFAULT ''`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS active_weekly_plan_by_class JSONB NOT NULL DEFAULT '{}'`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS weekly_conflict_policy JSONB`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS grades JSONB NOT NULL DEFAULT '[]'`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS classes JSONB NOT NULL DEFAULT '[]'`,
        sql`ALTER TABLE exam_data ADD COLUMN IF NOT EXISTS initialization JSONB NOT NULL DEFAULT '{}'`,
        sql`
        CREATE TABLE IF NOT EXISTS device_instances (
          instance_id TEXT PRIMARY KEY,
          grade_id TEXT NOT NULL DEFAULT '',
          class_id TEXT NOT NULL DEFAULT '',
          revoked BOOLEAN NOT NULL DEFAULT FALSE,
          page TEXT NOT NULL DEFAULT '',
          client_version TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL DEFAULT '',
          current_exam TEXT NOT NULL DEFAULT '',
          current_subject TEXT NOT NULL DEFAULT '',
          exam_start TEXT NOT NULL DEFAULT '',
          exam_end TEXT NOT NULL DEFAULT '',
          temporary_command JSONB,
          last_seen_at BIGINT NOT NULL DEFAULT 0,
          updated_at BIGINT NOT NULL
        )
      `,
        ensureUpdatedAtBigIntOnce(),
      ]);
      await sql`ALTER TABLE device_instances ADD COLUMN IF NOT EXISTS temporary_command JSONB`;
      await sql`
        INSERT INTO exam_data (id, items, title, updated_at)
        VALUES (1, '[]', '', 0)
        ON CONFLICT (id) DO NOTHING
      `;
    })().catch(err => { migratePromise = null; throw err; });
  }
  return migratePromise;
}

type ExamRow = {
  items?: unknown;
  title?: string;
  majors?: unknown;
  active_major_id?: string;
  alerts?: unknown;
  weekly_plans?: unknown;
  schedule_mode?: string;
  active_weekly_plan_id?: string;
  active_weekly_plan_by_class?: unknown;
  weekly_conflict_policy?: unknown;
  grades?: unknown;
  classes?: unknown;
  initialization?: unknown;
  updated_at?: number | string | null;
  bound_grade_id?: string | null;
  bound_class_id?: string | null;
  binding_revoked?: boolean | null;
};
type UpdatedRow = { updated_at: number | string };

function examPayload(row: ExamRow) {
  return {
    ok: true,
    items: row.items ?? [],
    title: row.title ?? '',
    majors: row.majors ?? [],
    activeMajorId: row.active_major_id ?? '',
    alerts: row.alerts ?? null,
    weeklyPlans: row.weekly_plans ?? [],
    scheduleMode: row.schedule_mode ?? 'major-only',
    activeWeeklyPlanId: row.active_weekly_plan_id ?? '',
    activeWeeklyPlanIdByClassId: row.active_weekly_plan_by_class ?? {},
    grades: row.grades ?? [],
    classes: row.classes ?? [],
    initialization: row.initialization ?? {},
    weeklyConflictPolicy: row.weekly_conflict_policy ?? null,
    updatedAt: Number(row.updated_at ?? 0),
  };
}

const sameJson = (left: unknown, right: unknown) => JSON.stringify(left ?? null) === JSON.stringify(right ?? null);
const allScope = (actor: AdminActor) => actor.permissions.includes('*') || actor.scopes.some(scope => scope.type === 'all');

function changedRecords(before: any[], after: any[]): any[] {
  const left = new Map((Array.isArray(before) ? before : []).map(item => [String(item?.id ?? ''), item]));
  const right = new Map((Array.isArray(after) ? after : []).map(item => [String(item?.id ?? ''), item]));
  const ids = new Set([...left.keys(), ...right.keys()]);
  return [...ids].filter(id => !sameJson(left.get(id), right.get(id))).flatMap(id => [left.get(id), right.get(id)].filter(Boolean));
}

function recordDiff(before: any[], after: any[]) {
  const left = new Map((Array.isArray(before) ? before : []).map(item => [String(item?.id ?? ''), item]));
  const right = new Map((Array.isArray(after) ? after : []).map(item => [String(item?.id ?? ''), item]));
  return {
    added: [...right.entries()].filter(([id]) => !left.has(id)).map(([, item]) => item),
    removed: [...left.entries()].filter(([id]) => !right.has(id)).map(([, item]) => item),
    updated: [...right.entries()].filter(([id, item]) => left.has(id) && !sameJson(left.get(id), item)).map(([, item]) => item),
  };
}

function validateMutation(actor: AdminActor, current: ReturnType<typeof examPayload>, body: Record<string, any>): { ok: true; actions: string[] } | { ok: false; error: string; permission?: Permission } {
  const actions: string[] = [];
  const need = (permission: Permission, label: string) => {
    if (!hasPermission(actor, permission)) return { ok: false as const, error: `当前账号无权修改${label}`, permission };
    actions.push(permission); return null;
  };
  const nextMajors = Array.isArray(body.majors) ? body.majors : current.majors;
  const nextGrades = Array.isArray(body.grades) ? body.grades : current.grades;
  const nextClasses = Array.isArray(body.classes) ? body.classes : current.classes;

  const majorDiff = recordDiff(current.majors, nextMajors);
  const itemDiff = recordDiff(current.items, body.items);
  const majorChanged = majorDiff.added.length > 0 || majorDiff.removed.length > 0 || majorDiff.updated.length > 0
    || itemDiff.added.length > 0 || itemDiff.removed.length > 0 || itemDiff.updated.length > 0
    || current.title !== String(body.title ?? '')
    || current.activeMajorId !== String(body.activeMajorId ?? '');
  if (majorChanged) {
    if (majorDiff.added.length) { const denied = need('major.create', '新建大型考试'); if (denied) return denied; }
    if (majorDiff.removed.length || itemDiff.removed.length) { const denied = need('major.delete', '删除考试'); if (denied) return denied; }
    if (majorDiff.updated.length || itemDiff.added.length || itemDiff.updated.length || current.title !== String(body.title ?? '') || current.activeMajorId !== String(body.activeMajorId ?? '')) { const denied = need('major.edit', '大型考试'); if (denied) return denied; }
    const classes = new Map((nextClasses as any[]).map(item => [String(item?.id ?? ''), item]));
    for (const major of changedRecords(current.majors, nextMajors)) {
      const gradeIds = Array.isArray(major?.targetGradeIds) ? major.targetGradeIds.map(String) : [];
      const classIds = Array.isArray(major?.targetClassIds) ? major.targetClassIds.map(String) : [];
      if (!gradeIds.length && !classIds.length && !allScope(actor)) return { ok: false, error: '仅全校范围管理员可以修改全校大型考试' };
      if (gradeIds.some((id: string) => !canAccessGrade(actor, id))) return { ok: false, error: '大型考试包含当前账号无权管理的年级' };
      if (classIds.some((id: string) => { const item: any = classes.get(id); return !item || !canAccessClass(actor, String(item.gradeId ?? ''), id); })) return { ok: false, error: '大型考试包含当前账号无权管理的班级' };
    }
  }

  if (body.weeklyPlans !== undefined && !sameJson(current.weeklyPlans, body.weeklyPlans)) {
    const diff = recordDiff(current.weeklyPlans ?? [], body.weeklyPlans ?? []);
    if (diff.added.length) { const denied = need('weekly.create', '新建周测计划'); if (denied) return denied; }
    if (diff.added.length > 1) { const denied = need('weekly.copy', '批量应用周测计划'); if (denied) return denied; }
    if (diff.removed.length) { const denied = need('weekly.delete', '删除周测计划'); if (denied) return denied; }
    if (diff.updated.length) { const denied = need('weekly.edit', '周测计划'); if (denied) return denied; }
    for (const plan of changedRecords(current.weeklyPlans ?? [], body.weeklyPlans ?? [])) {
      if (!canAccessClass(actor, String(plan?.gradeId ?? ''), String(plan?.classId ?? ''))) return { ok: false, error: '周测计划超出当前账号的班级管理范围' };
    }
  }
  if ((body.activeWeeklyPlanId !== undefined && !sameJson(current.activeWeeklyPlanId, body.activeWeeklyPlanId))
      || (body.activeWeeklyPlanIdByClassId !== undefined && !sameJson(current.activeWeeklyPlanIdByClassId, body.activeWeeklyPlanIdByClassId))) {
    const denied = need('weekly.edit', '周测生效计划'); if (denied) return denied;
    const before = current.activeWeeklyPlanIdByClassId ?? {};
    const after = body.activeWeeklyPlanIdByClassId ?? before;
    const classMap = new Map((nextClasses as any[]).map(item => [String(item?.id ?? ''), item]));
    const changedClassIds = new Set([...Object.keys(before), ...Object.keys(after)].filter(id => before[id] !== after[id]));
    for (const classId of changedClassIds) {
      const schoolClass: any = classMap.get(classId);
      if (!schoolClass || !canAccessClass(actor, String(schoolClass.gradeId ?? ''), classId)) return { ok: false, error: '生效周测计划超出当前账号的班级管理范围' };
    }
  }
  if (body.grades !== undefined && !sameJson(current.grades, body.grades)) {
    const denied = need('school.grade_manage', '年级结构'); if (denied) return denied;
    if (!allScope(actor)) return { ok: false, error: '只有全校范围管理员可以增删年级' };
  }
  if (body.classes !== undefined && !sameJson(current.classes, body.classes)) {
    const denied = need('school.class_manage', '班级结构'); if (denied) return denied;
    for (const schoolClass of changedRecords(current.classes ?? [], body.classes ?? [])) {
      if (!canAccessGrade(actor, String(schoolClass?.gradeId ?? ''))) return { ok: false, error: '班级变更超出当前账号的年级管理范围' };
    }
  }
  if (body.scheduleMode !== undefined && current.scheduleMode !== body.scheduleMode) {
    const denied = need('schedule.mode_edit', '全校运行模式'); if (denied) return denied;
    if (!allScope(actor)) return { ok: false, error: '只有全校范围管理员可以修改运行模式' };
  }
  if (body.weeklyConflictPolicy !== undefined && !sameJson(current.weeklyConflictPolicy, body.weeklyConflictPolicy)) {
    const denied = need('schedule.conflict_edit', '大型考试冲突策略'); if (denied) return denied;
    if (!allScope(actor)) return { ok: false, error: '只有全校范围管理员可以修改冲突策略' };
  }
  if (body.alerts !== undefined && !sameJson(current.alerts, body.alerts)) {
    const denied = need('alerts.edit', '全屏提醒'); if (denied) return denied;
  }
  if (body.initialization !== undefined && !sameJson(current.initialization, body.initialization)) {
    const denied = need('initialization.run', '初始化设置'); if (denied) return denied;
    if (!allScope(actor)) return { ok: false, error: '只有超级管理员可以执行初始化' };
  }
  return { ok: true, actions: [...new Set(actions)] };
}

// 判断是否因“表/列尚未创建”报错，仅在首次遇到时才跑迁移并重试。
function missingRelation(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return /does not exist|undefined_table|undefined_column/i.test(msg);
}

function updatedAtIntegerOverflow(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  const code = typeof err === 'object' && err !== null && 'code' in err
    ? String((err as { code?: unknown }).code ?? '')
    : '';
  return code === '22003' && /out of range for type integer/i.test(msg);
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const startedAt = Date.now();
  // Short edge cache reduces repeated US→Singapore database reads while keeping updates prompt.
  if (req.method === 'GET') res.setHeader('Cache-Control', 'public, s-maxage=10, stale-while-revalidate=50');
  else res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') { res.status(204).end(); return; }

  try {
    const sql = database();

    const action = String(req.method === 'GET' ? req.query?.action ?? '' : req.body?.action ?? '');
    if (action === 'bootstrap') {
      res.setHeader('Cache-Control', 'private, no-store');
      if (req.method !== 'GET') { res.status(405).json({ ok: false, error: 'Method not allowed' }); return; }
      const instanceId = String(req.query?.instanceId ?? '').trim().slice(0, 128);
      if (!instanceId) { res.status(400).json({ ok: false, error: 'instanceId is required' }); return; }
      const selectBootstrap = async (): Promise<ExamRow[]> => (
        await sql`
          SELECT items, title, majors, active_major_id, alerts, weekly_plans, schedule_mode,
                 active_weekly_plan_id, active_weekly_plan_by_class, weekly_conflict_policy, grades, classes, initialization, updated_at,
                 (SELECT grade_id FROM device_instances WHERE instance_id = ${instanceId}) AS bound_grade_id,
                 (SELECT class_id FROM device_instances WHERE instance_id = ${instanceId}) AS bound_class_id,
                 (SELECT revoked FROM device_instances WHERE instance_id = ${instanceId}) AS binding_revoked
          FROM exam_data
          WHERE id = 1
        `
      ) as unknown as ExamRow[];
      let rows: ExamRow[];
      try { rows = await selectBootstrap(); }
      catch (error) { if (!missingRelation(error)) throw error; await ensureTableOnce(); rows = await selectBootstrap(); }
      const row = rows[0] ?? {};
      res.setHeader('Server-Timing', `app;dur=${Date.now() - startedAt}`);
      res.status(200).json({ ...examPayload(row), binding: row.bound_class_id == null ? null : { gradeId: row.bound_grade_id ?? '', classId: row.bound_class_id, revoked: row.binding_revoked === true } });
      return;
    }
    if (action === 'device-bindings') {
      res.setHeader('Cache-Control', 'no-store');
      if (req.method !== 'GET') { res.status(405).json({ ok: false, error: 'Method not allowed' }); return; }
      let deviceActor: AdminActor | null = null;
      if (await isPasswordRequired()) {
        deviceActor = await requireActor(req, res, 'device.read');
        if (!deviceActor) return;
      }
      const selectBindings = async () => (
        await sql`SELECT * FROM device_instances ORDER BY updated_at DESC LIMIT 2001`
      ) as unknown as Array<Record<string, any>>;
      let rows: Awaited<ReturnType<typeof selectBindings>>;
      try { rows = await selectBindings(); }
      catch (error) { if (!missingRelation(error)) throw error; await ensureTableOnce(); rows = await selectBindings(); }
      if (deviceActor) rows = rows.filter(row => canAccessClass(deviceActor!, String(row.grade_id ?? ''), String(row.class_id ?? '')));
      const truncated = rows.length > 500;
      res.status(200).json({
        ok: true,
        bindings: rows.slice(0, 500).map(row => ({ instanceId: row.instance_id, gradeId: row.grade_id, classId: row.class_id, revoked: row.revoked === true, page: row.page, clientVersion: row.client_version, status: row.status, currentExam: row.current_exam, currentSubject: row.current_subject, examStart: row.exam_start, examEnd: row.exam_end, lastSeenAt: Number(row.last_seen_at), updatedAt: Number(row.updated_at) })),
        truncated,
      });
      return;
    }
    if (action === 'device-binding') {
      const instanceId = String(req.method === 'GET' ? req.query?.instanceId ?? '' : req.body?.instanceId ?? '').trim().slice(0, 128);
      if (!instanceId) { res.status(400).json({ ok: false, error: 'instanceId is required' }); return; }
      const runBinding = async () => {
        if (req.method === 'GET') {
          const rows = await sql`SELECT grade_id, class_id, revoked FROM device_instances WHERE instance_id = ${instanceId}` as unknown as Array<{ grade_id?: string; class_id?: string; revoked?: boolean }>;
          res.status(200).json({ ok: true, binding: rows[0] ? { gradeId: rows[0].grade_id ?? '', classId: rows[0].class_id ?? '', revoked: rows[0].revoked === true } : null });
          return;
        }
        if (req.method === 'POST') {
          const gradeId = String(req.body?.gradeId ?? '').trim().slice(0, 128);
          const classId = String(req.body?.classId ?? '').trim().slice(0, 128);
          if (!gradeId || !classId) { res.status(400).json({ ok: false, error: 'gradeId and classId are required' }); return; }
          const updatedAt = Date.now();
          await sql`
            INSERT INTO device_instances (instance_id, grade_id, class_id, revoked, updated_at)
            VALUES (${instanceId}, ${gradeId}, ${classId}, FALSE, ${updatedAt})
            ON CONFLICT (instance_id) DO UPDATE SET grade_id = EXCLUDED.grade_id, class_id = EXCLUDED.class_id, revoked = FALSE, updated_at = EXCLUDED.updated_at
          `;
          res.status(200).json({ ok: true, binding: { gradeId, classId, revoked: false }, updatedAt });
          return;
        }
        res.status(405).json({ ok: false, error: 'Method not allowed' });
      };
      try { await runBinding(); }
      catch (error) { if (!missingRelation(error)) throw error; await ensureTableOnce(); await runBinding(); }
      return;
    }
    if (action === 'device-heartbeat' && req.method === 'POST') {
      const instanceId = String(req.body?.instanceId ?? '').trim().slice(0, 128);
      if (!instanceId) { res.status(400).json({ ok: false, error: 'instanceId is required' }); return; }
      const now = Date.now();
      const value = (key: string, max = 160) => String(req.body?.[key] ?? '').trim().slice(0, max);
      const run = async () => {
        const acknowledgedCommandId = value('acknowledgedCommandId', 128);
        if (acknowledgedCommandId) await sql`UPDATE device_instances SET temporary_command=NULL WHERE instance_id=${instanceId} AND temporary_command->>'id'=${acknowledgedCommandId}`;
        await sql`INSERT INTO device_instances (instance_id, page, client_version, status, current_exam, current_subject, exam_start, exam_end, last_seen_at, updated_at)
          VALUES (${instanceId}, ${value('page')}, ${value('clientVersion', 40)}, ${value('status', 40)}, ${value('currentExam')}, ${value('currentSubject')}, ${value('examStart', 40)}, ${value('examEnd', 40)}, ${now}, ${now})
          ON CONFLICT (instance_id) DO UPDATE SET page=EXCLUDED.page, client_version=EXCLUDED.client_version, status=EXCLUDED.status, current_exam=EXCLUDED.current_exam, current_subject=EXCLUDED.current_subject, exam_start=EXCLUDED.exam_start, exam_end=EXCLUDED.exam_end, last_seen_at=EXCLUDED.last_seen_at`;
        const rows = await sql`SELECT revoked, temporary_command FROM device_instances WHERE instance_id=${instanceId}` as unknown as Array<{ revoked: boolean; temporary_command?: unknown }>;
        res.status(200).json({ ok: true, revoked: rows[0]?.revoked === true, command: rows[0]?.temporary_command ?? null });
      };
      try { await run(); } catch (error) { if (!missingRelation(error)) throw error; await ensureTableOnce(); await run(); }
      return;
    }
    if (action === 'device-command' && req.method === 'POST') {
      const instanceId = String(req.body?.instanceId ?? '').trim().slice(0, 128);
      const commandAction = String(req.body?.commandAction ?? '');
      if (!instanceId || !['pause', 'resume', 'extend', 'end'].includes(commandAction)) { res.status(400).json({ ok: false, error: 'Invalid device command' }); return; }
      await ensureTableOnce();
      let deviceActor: AdminActor | null = null;
      if (await isPasswordRequired()) {
        deviceActor = await requireActor(req, res, 'device.revoke'); if (!deviceActor) return;
        const bindings = await sql`SELECT grade_id, class_id FROM device_instances WHERE instance_id=${instanceId}` as unknown as Array<{ grade_id: string; class_id: string }>;
        if (bindings[0] && !canAccessClass(deviceActor, bindings[0].grade_id, bindings[0].class_id)) { res.status(403).json({ ok: false, error: '设备超出当前账号的管理范围' }); return; }
      }
      const command = { id: `cmd_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, action: commandAction, minutes: commandAction === 'extend' ? Math.min(120, Math.max(1, Number(req.body?.minutes) || 5)) : undefined, createdAt: Date.now() };
      await sql`UPDATE device_instances SET temporary_command=${JSON.stringify(command)}::jsonb, updated_at=${Date.now()} WHERE instance_id=${instanceId}`;
      await writeAudit(deviceActor, `device.temporary.${commandAction}`, 'device', instanceId);
      res.status(200).json({ ok: true, command }); return;
    }
    if (action === 'device-revoke' && req.method === 'POST') {
      const instanceId = String(req.body?.instanceId ?? '').trim().slice(0, 128);
      await ensureTableOnce();
      let deviceActor: AdminActor | null = null;
      if (await isPasswordRequired()) {
        deviceActor = await requireActor(req, res, 'device.revoke'); if (!deviceActor) return;
        const bindings = await sql`SELECT grade_id, class_id FROM device_instances WHERE instance_id=${instanceId}` as unknown as Array<{ grade_id: string; class_id: string }>;
        if (bindings[0] && !canAccessClass(deviceActor, bindings[0].grade_id, bindings[0].class_id)) { res.status(403).json({ ok: false, error: '设备超出当前账号的管理范围' }); return; }
      }
      await sql`UPDATE device_instances SET revoked=TRUE, grade_id='', class_id='', updated_at=${Date.now()} WHERE instance_id=${instanceId}`;
      await writeAudit(deviceActor, 'device.revoke', 'device', instanceId);
      res.status(200).json({ ok: true }); return;
    }
    if (action === 'reset-data' && req.method === 'POST') {
      let resetActor: AdminActor | null = null;
      if (await isPasswordRequired()) {
        resetActor = await requireActor(req, res, 'initialization.run'); if (!resetActor) return;
        if (!allScope(resetActor)) { res.status(403).json({ ok: false, error: '只有超级管理员可以重置数据库' }); return; }
      }
      await ensureTableOnce();
      const categories = Array.isArray(req.body?.categories) ? req.body.categories.map(String) : [];
      const resetAll = categories.includes('all');
      const resetMajor = resetAll || categories.includes('major');
      const resetWeekly = resetAll || categories.includes('weekly');
      const resetSchool = resetAll || categories.includes('school');
      const resetSettings = resetAll || categories.includes('settings');
      const resetDevices = resetAll || categories.includes('devices') || resetSchool;
      if (![resetMajor, resetWeekly, resetSchool, resetSettings, resetDevices].some(Boolean)) { res.status(400).json({ ok: false, error: '请选择需要重置的数据' }); return; }
      const at = Date.now();
      await sql`UPDATE exam_data SET
        items=CASE WHEN ${resetMajor} THEN '[]'::jsonb ELSE items END,
        title=CASE WHEN ${resetMajor} THEN '' ELSE title END,
        majors=CASE WHEN ${resetMajor} THEN '[]'::jsonb ELSE majors END,
        active_major_id=CASE WHEN ${resetMajor} THEN '' ELSE active_major_id END,
        weekly_plans=CASE WHEN ${resetWeekly || resetSchool} THEN '[]'::jsonb ELSE weekly_plans END,
        active_weekly_plan_id=CASE WHEN ${resetWeekly || resetSchool} THEN '' ELSE active_weekly_plan_id END,
        active_weekly_plan_by_class=CASE WHEN ${resetWeekly || resetSchool} THEN '{}'::jsonb ELSE active_weekly_plan_by_class END,
        grades=CASE WHEN ${resetSchool} THEN '[]'::jsonb ELSE grades END,
        classes=CASE WHEN ${resetSchool} THEN '[]'::jsonb ELSE classes END,
        initialization=CASE WHEN ${resetSchool} THEN '{}'::jsonb ELSE initialization END,
        alerts=CASE WHEN ${resetSettings} THEN NULL ELSE alerts END,
        schedule_mode=CASE WHEN ${resetSettings} THEN 'major-only' ELSE schedule_mode END,
        weekly_conflict_policy=CASE WHEN ${resetSettings} THEN NULL ELSE weekly_conflict_policy END,
        updated_at=${at} WHERE id=1`;
      if (resetDevices) await sql`DELETE FROM device_instances`;
      getCache = null;
      await writeAudit(resetActor, 'database.reset', 'exam_data', '1', { categories });
      res.status(200).json({ ok: true, updatedAt: at }); return;
    }

    if (req.method === 'GET') {
      // Warm cache and ETag avoid repeat database reads for unchanged display data.
      if (getCache && getCache.expiresAt > Date.now()) {
        res.setHeader('ETag', getCache.etag);
        if (req.headers['if-none-match'] === getCache.etag) { res.status(304).end(); return; }
        res.setHeader('Server-Timing', `app;dur=${Date.now() - startedAt}`); res.setHeader('Content-Type', 'application/json'); res.status(200).send(getCache.body); return;
      }
      // 快路径：直接查询（一次往返）；仅当表/列缺失时才迁移后重试。
      const selectRow = async (): Promise<ExamRow[]> => (
        await sql`SELECT items, title, majors, active_major_id, alerts, weekly_plans, schedule_mode, active_weekly_plan_id, active_weekly_plan_by_class, weekly_conflict_policy, grades, classes, initialization, updated_at FROM exam_data WHERE id = 1`
      ) as unknown as ExamRow[];
      let rows: ExamRow[];
      try {
        rows = await selectRow();
      } catch (e) {
        if (!missingRelation(e)) throw e;
        await ensureTableOnce();
        rows = await selectRow();
      }
      const row = rows[0] ?? { items: [], title: '', majors: [], active_major_id: '', alerts: null, weekly_plans: [], schedule_mode: 'major-only', active_weekly_plan_id: '', active_weekly_plan_by_class: {}, weekly_conflict_policy: null, updated_at: 0 };
      const payload = examPayload(row);
      const body = JSON.stringify(payload); const etag = `\"exam-${payload.updatedAt}\"`;
      getCache = { body, etag, expiresAt: Date.now() + GET_CACHE_MS };
      res.setHeader('ETag', etag);
      if (req.headers['if-none-match'] === etag) { res.status(304).end(); return; }
      res.setHeader('Server-Timing', `app;dur=${Date.now() - startedAt}`); res.setHeader('Content-Type', 'application/json'); res.status(200).send(body);
      return;
    }

    if (req.method === 'POST') {
      let actor: AdminActor | null = null;
      if (await isPasswordRequired()) {
        actor = await requireActor(req, res);
        if (!actor) return;
      }
      const { items, title, majors, activeMajorId, alerts, weeklyPlans, scheduleMode, activeWeeklyPlanId, activeWeeklyPlanIdByClassId, weeklyConflictPolicy, grades, classes, initialization, baseUpdatedAt } = req.body ?? {};
      if (!Array.isArray(items)) { res.status(400).json({ ok: false, error: 'items must be an array' }); return; }
      if (actor) {
        let currentRows: ExamRow[];
        try {
          currentRows = await sql`SELECT items, title, majors, active_major_id, alerts, weekly_plans, schedule_mode, active_weekly_plan_id, active_weekly_plan_by_class, weekly_conflict_policy, grades, classes, initialization, updated_at FROM exam_data WHERE id=1` as unknown as ExamRow[];
        } catch (error) {
          if (!missingRelation(error)) throw error;
          await ensureTableOnce();
          currentRows = await sql`SELECT items, title, majors, active_major_id, alerts, weekly_plans, schedule_mode, active_weekly_plan_id, active_weekly_plan_by_class, weekly_conflict_policy, grades, classes, initialization, updated_at FROM exam_data WHERE id=1` as unknown as ExamRow[];
        }
        const permission = validateMutation(actor, examPayload(currentRows[0] ?? {}), req.body ?? {});
        if (!permission.ok) { res.status(403).json(permission); return; }
      }
      const expectedVersion = Number(baseUpdatedAt ?? 0);
      const updatedAt = Date.now();
      const runUpdate = async (): Promise<UpdatedRow[]> => (
        await sql`
          UPDATE exam_data
          SET items = ${JSON.stringify(items)}::jsonb,
              title = ${typeof title === 'string' ? title : ''},
              majors = ${JSON.stringify(Array.isArray(majors) ? majors : [])}::jsonb,
              active_major_id = ${typeof activeMajorId === 'string' ? activeMajorId : ''},
              alerts = ${alerts && typeof alerts === 'object' ? JSON.stringify(alerts) : null}::jsonb,
              -- 周测字段：仅当请求显式携带时才覆写，否则 COALESCE 保留既有值（后台保存不带周测→不丢失）。
              weekly_plans = COALESCE(${weeklyPlans !== undefined ? JSON.stringify(Array.isArray(weeklyPlans) ? weeklyPlans : []) : null}::jsonb, weekly_plans),
              schedule_mode = COALESCE(${typeof scheduleMode === 'string' ? scheduleMode : null}, schedule_mode),
              active_weekly_plan_id = COALESCE(${typeof activeWeeklyPlanId === 'string' ? activeWeeklyPlanId : null}, active_weekly_plan_id),
              active_weekly_plan_by_class = COALESCE(${activeWeeklyPlanIdByClassId && typeof activeWeeklyPlanIdByClassId === 'object' ? JSON.stringify(activeWeeklyPlanIdByClassId) : null}::jsonb, active_weekly_plan_by_class),
              grades = COALESCE(${Array.isArray(grades) ? JSON.stringify(grades) : null}::jsonb, grades),
              classes = COALESCE(${Array.isArray(classes) ? JSON.stringify(classes) : null}::jsonb, classes),
              initialization = COALESCE(${initialization && typeof initialization === 'object' ? JSON.stringify(initialization) : null}::jsonb, initialization),
              weekly_conflict_policy = COALESCE(${weeklyConflictPolicy && typeof weeklyConflictPolicy === 'object' ? JSON.stringify(weeklyConflictPolicy) : null}::jsonb, weekly_conflict_policy),
              updated_at = ${updatedAt}
          -- 显式 BIGINT：毫秒级 baseUpdatedAt 不能在与字面量 0 比较时被 PostgreSQL 推断为 INTEGER。
          WHERE id = 1 AND (${expectedVersion}::BIGINT <= 0 OR updated_at = ${expectedVersion}::BIGINT)
          RETURNING updated_at
        `
      ) as unknown as UpdatedRow[];
      let updatedRows: UpdatedRow[];
      try {
        updatedRows = await runUpdate();
      } catch (e) {
        if (missingRelation(e)) {
          await ensureTableOnce();
          updatedRows = await runUpdate();
        } else if (updatedAtIntegerOverflow(e)) {
          // 旧实例数据库的 updated_at 仍为 INTEGER：自动升级后重试本次保存。
          await ensureUpdatedAtBigIntOnce();
          updatedRows = await runUpdate();
        } else {
          throw e;
        }
      }
      if (!updatedRows?.length) {
        const rows = (await sql`SELECT items, title, majors, active_major_id, alerts, weekly_plans, schedule_mode, active_weekly_plan_id, active_weekly_plan_by_class, weekly_conflict_policy, grades, classes, initialization, updated_at FROM exam_data WHERE id = 1`) as unknown as ExamRow[];
        const row = rows[0] ?? {};
        const { ok: _ok, ...remote } = examPayload(row);
        res.status(409).json({ ok: false, error: 'Conflict', remote });
        return;
      }
      getCache = null;
      if (actor) await writeAudit(actor, 'exam-data.update', 'exam_data', '1', { updatedAt });
      res.setHeader('Server-Timing', `app;dur=${Date.now() - startedAt}`); res.status(200).json({ ok: true, updatedAt });
      return;
    }

    res.status(405).json({ ok: false, error: 'Method not allowed' });
  } catch (error: unknown) {
    console.error('Exam API error:', error);
    res.status(500).json({ ok: false, error: error instanceof Error ? error.message : 'Database error' });
  }
}
